package cl.computec.ui.panel;

import cl.computec.dao.EquipoDAO;
import cl.computec.model.Equipo;
import cl.computec.util.Formatters;

import javax.swing.*;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public class EquiposPanel extends JPanel {

    private final JLabel status;

    private final JComboBox<String> cbTipo = new JComboBox<>(new String[]{"desktop", "laptop"});
    private final JTextField txtModelo = new JTextField(20);
    private final JTextField txtCPU = new JTextField(20);
    private final JSpinner spDisco = new JSpinner(new SpinnerNumberModel(512000, 1, 10_000_000, 1)); // MB
    private final JSpinner spRAM = new JSpinner(new SpinnerNumberModel(8, 1, 1024, 1)); // GB
    private final JSpinner spPrecio = new JSpinner(new SpinnerNumberModel(499990, 0, 10_000_000, 1000));

    // Desktop
    private final JPanel panelDesktop = new JPanel(new GridBagLayout());
    private final JSpinner spFuente = new JSpinner(new SpinnerNumberModel(500, 100, 2000, 50));
    private final JComboBox<String> cbFactor = new JComboBox<>(new String[]{"atx", "eatx", "microatx", "itx", "otro"});

    // Laptop
    private final JPanel panelLaptop = new JPanel(new GridBagLayout());
    private final JSpinner spPantalla = new JSpinner(new SpinnerNumberModel(14.0, 10.0, 20.0, 0.1));
    private final JCheckBox chkTouch = new JCheckBox("Touch");
    private final JSpinner spUSB = new JSpinner(new SpinnerNumberModel(3, 0, 10, 1));

    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnListar = new JButton("Listar");
    private final JButton btnLimpiar = new JButton("Limpiar");
    private final JButton btnEliminar = new JButton("Eliminar seleccionado");

    // Filtros (tabla)
    private final JComboBox<String> cbFiltroTipo = new JComboBox<>(new String[]{"todos", "desktop", "laptop"});
    private final JComboBox<String> cbBuscarPor = new JComboBox<>(new String[]{"Modelo", "CPU"});
    private final JTextField txtBuscar = new JTextField(18);

    // Tabla
    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Tipo", "Modelo", "CPU", "RAM(GB)", "Disco(MB)", "Precio"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modelo);
    private TableRowSorter<DefaultTableModel> sorter;

    // menu
    private final JPopupMenu popup = new JPopupMenu();
    private final JMenuItem miEliminar = new JMenuItem("Eliminar seleccionado");

    private final EquipoDAO dao = new EquipoDAO();

    public EquiposPanel(JLabel status) {
        this.status = status;
        setLayout(new BorderLayout(6, 6));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("Tipo"), c);
        c.gridx = 1;
        form.add(cbTipo, c);
        y++;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("Modelo"), c);
        c.gridx = 1;
        form.add(txtModelo, c);
        y++;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("CPU"), c);
        c.gridx = 1;
        form.add(txtCPU, c);
        y++;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("Disco (MB)"), c);
        c.gridx = 1;
        form.add(spDisco, c);
        y++;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("RAM (GB)"), c);
        c.gridx = 1;
        form.add(spRAM, c);
        y++;
        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("Precio"), c);
        c.gridx = 1;
        form.add(spPrecio, c);
        y++;

        GridBagConstraints d = new GridBagConstraints();
        d.insets = new Insets(4, 4, 4, 4);
        d.fill = GridBagConstraints.HORIZONTAL;
        d.gridx = 0;
        d.gridy = 0;
        panelDesktop.add(new JLabel("Fuente (W)"), d);
        d.gridx = 1;
        panelDesktop.add(spFuente, d);
        d.gridx = 0;
        d.gridy = 1;
        panelDesktop.add(new JLabel("Factor forma"), d);
        d.gridx = 1;
        panelDesktop.add(cbFactor, d);

        GridBagConstraints l = new GridBagConstraints();
        l.insets = new Insets(4, 4, 4, 4);
        l.fill = GridBagConstraints.HORIZONTAL;
        l.gridx = 0;
        l.gridy = 0;
        panelLaptop.add(new JLabel("Pantalla (pulg)"), l);
        l.gridx = 1;
        panelLaptop.add(spPantalla, l);
        l.gridx = 0;
        l.gridy = 1;
        panelLaptop.add(new JLabel("Puertos USB"), l);
        l.gridx = 1;
        panelLaptop.add(spUSB, l);
        l.gridx = 1;
        l.gridy = 2;
        panelLaptop.add(chkTouch, l);

        JPanel panelTipo = new JPanel(new CardLayout());
        panelTipo.add(panelDesktop, "desktop");
        panelTipo.add(panelLaptop, "laptop");
        ((CardLayout) panelTipo.getLayout()).show(panelTipo, "desktop");

        c.gridx = 0;
        c.gridy = y;
        form.add(new JLabel("Específico"), c);
        c.gridx = 1;
        form.add(panelTipo, c);
        y++;

        // ======= Acciones =======
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        acciones.add(btnGuardar);
        acciones.add(btnListar);
        acciones.add(btnEliminar);
        acciones.add(btnLimpiar);
        acciones.add(new JLabel(" | Tipo:"));
        acciones.add(cbFiltroTipo);
        acciones.add(new JLabel(" Buscar por:"));
        acciones.add(cbBuscarPor);
        acciones.add(txtBuscar);

        // ======= Tabla =======
        tabla.setAutoCreateRowSorter(true);
        sorter = new TableRowSorter<>(modelo);
        tabla.setRowSorter(sorter);

        DefaultTableCellRenderer priceR = new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value instanceof java.math.BigDecimal) {
                    setText(Formatters.clp((java.math.BigDecimal) value));
                } else if (value != null) {
                    setText(Formatters.clp(new java.math.BigDecimal(value.toString())));
                } else {
                    setText("");
                }
            }
        };
        DefaultTableCellRenderer mbR = new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value == null) {
                    setText("");
                } else {
                    setText(Formatters.mb(Integer.parseInt(value.toString())));
                }
            }
        };
        tabla.getColumnModel().getColumn(5).setCellRenderer(mbR);   // Disco (MB)
        tabla.getColumnModel().getColumn(6).setCellRenderer(priceR); // Precio

        JScrollPane sp = new JScrollPane(tabla);

        popup.add(miEliminar);
        tabla.setComponentPopupMenu(popup);

        // ======= Layout principal =======
        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.CENTER);
        north.add(acciones, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        // ======= Eventos =======
        cbTipo.addActionListener(e -> {
            String t = (String) cbTipo.getSelectedItem();
            ((CardLayout) panelTipo.getLayout()).show(panelTipo, t);
        });
        btnLimpiar.addActionListener(e -> limpiar());
        btnGuardar.addActionListener(e -> guardar());
        btnListar.addActionListener(e -> listar());
        btnEliminar.addActionListener(e -> eliminarSeleccionado());
        miEliminar.addActionListener(e -> eliminarSeleccionado());

        tabla.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), "delRow");
        tabla.getActionMap().put("delRow", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarSeleccionado();
            }
        });

        cbFiltroTipo.addActionListener(e -> listar());

        txtBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                applyQuickFilter();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                applyQuickFilter();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                applyQuickFilter();
            }
        });
        cbBuscarPor.addActionListener(e -> applyQuickFilter());

        // Carga inicial
        listar();
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    private void limpiar() {
        txtModelo.setText("");
        txtCPU.setText("");
        spDisco.setValue(512000);
        spRAM.setValue(8);
        spPrecio.setValue(499990);
        spFuente.setValue(500);
        cbFactor.setSelectedIndex(0);
        spPantalla.setValue(14.0);
        chkTouch.setSelected(false);
        spUSB.setValue(3);
        cbTipo.setSelectedIndex(0);
        txtModelo.requestFocus();
        tabla.clearSelection();
        setStatus("Formulario limpio");
    }

    private boolean validarBase() {
        if (txtModelo.getText().trim().isEmpty() || txtCPU.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Modelo y CPU son obligatorios.", "Validación",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private Integer getSelectedId() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            return null;
        }
        int modelRow = tabla.convertRowIndexToModel(row);
        Object val = modelo.getValueAt(modelRow, 0);
        return val == null ? null : Integer.parseInt(val.toString());
    }

    // ===== Acciones =====
    private void guardar() {
        if (!validarBase()) {
            return;
        }
        String tipo = (String) cbTipo.getSelectedItem();
        String modeloTxt = txtModelo.getText().trim();
        String cpu = txtCPU.getText().trim();
        int disco = (Integer) spDisco.getValue();
        int ram = (Integer) spRAM.getValue();
        BigDecimal precio = new BigDecimal(String.valueOf(((Number) spPrecio.getValue()).longValue()));

        try {
            int id;
            if ("desktop".equalsIgnoreCase(tipo)) {
                int fuente = (Integer) spFuente.getValue();
                String factor = (String) cbFactor.getSelectedItem();
                id = dao.insertDesktop(modeloTxt, cpu, disco, ram, precio, fuente, factor);
            } else {
                double pantalla = ((Number) spPantalla.getValue()).doubleValue();
                boolean touch = chkTouch.isSelected();
                int usb = (Integer) spUSB.getValue();
                id = dao.insertLaptop(modeloTxt, cpu, disco, ram, precio, pantalla, touch, usb);
            }
            JOptionPane.showMessageDialog(this, "Equipo guardado con ID " + id);
            listar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            String filtroTipo = (String) cbFiltroTipo.getSelectedItem();
            List<Equipo> data = dao.listByTipo(filtroTipo);
            modelo.setRowCount(0);
            for (Equipo e : data) {
                modelo.addRow(new Object[]{
                    e.getId(), e.getTipo(), e.getModelo(), e.getCpu(),
                    e.getRamGb(), e.getDiscoMb(), e.getPrecio()
                });
            }
            // Mantener búsqueda rápida aplicada
            applyQuickFilter();
            setStatus("Equipos listados: " + data.size());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void applyQuickFilter() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }

        int col = cbBuscarPor.getSelectedIndex() == 0 ? 2 : 3;
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q), col));
    }

    private void eliminarSeleccionado() {
        Integer id = getSelectedId();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Selecciona una fila para eliminar.", "Atención",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "¿Eliminar equipo ID " + id + "?", "Confirmar",
                JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            dao.delete(id);
            JOptionPane.showMessageDialog(this, "Equipo eliminado: " + id);
            listar();
        } catch (Exception ex) {

            boolean esFK = ex instanceof SQLIntegrityConstraintViolationException
                    || (ex.getMessage() != null && ex.getMessage().toLowerCase().contains("foreign key"));
            if (esFK) {
                try {
                    boolean tieneVenta = dao.hasVenta(id);
                    if (tieneVenta) {
                        int op2 = JOptionPane.showConfirmDialog(this,
                                "Este equipo tiene ventas registradas.\n"
                                + "¿Eliminar TAMBIÉN sus ventas y luego el equipo? (cascada)",
                                "Tiene ventas", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                        if (op2 == JOptionPane.YES_OPTION) {
                            dao.deleteCascade(id);
                            JOptionPane.showMessageDialog(this, "Ventas y equipo eliminados.");
                            listar();
                            return;
                        }
                    }
                } catch (Exception inner) {
                    JOptionPane.showMessageDialog(this, inner.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }
}
