package cl.computec.patterns.decorator;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescuentoPorcentaje implements Descuento {

    private final Descuento inner;
    private final BigDecimal porcentaje; // 0.10 = 10%

    public DescuentoPorcentaje(Descuento inner, BigDecimal porcentaje) {
        this.inner = inner;
        this.porcentaje = porcentaje;
    }

    @Override
    public BigDecimal aplicar(BigDecimal precioBase) {
        BigDecimal base = inner.aplicar(precioBase);
        return base.subtract(base.multiply(porcentaje)).setScale(2, RoundingMode.HALF_UP);
    }
}
