package cl.computec.patterns.command;

public interface Command {

    void execute();
}
