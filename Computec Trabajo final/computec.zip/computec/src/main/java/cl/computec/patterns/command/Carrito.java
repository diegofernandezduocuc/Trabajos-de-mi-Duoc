package cl.computec.patterns.command;

import cl.computec.model.Equipo;

public class Carrito {

    private Equipo equipo;

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo e) {
        this.equipo = e;
    }

    public void clear() {
        this.equipo = null;
    }

    public boolean isEmpty() {
        return equipo == null;
    }
}
