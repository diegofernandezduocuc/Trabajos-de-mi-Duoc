package cl.computec.model;

public class Desktop extends Equipo {

    private int fuenteWatts;
    private String factorForma; // atx/eatx/microatx/itx/otro

    public Desktop() {
        this.tipo = "desktop";
    }

    public int getFuenteWatts() {
        return fuenteWatts;
    }

    public void setFuenteWatts(int fuenteWatts) {
        this.fuenteWatts = fuenteWatts;
    }

    public String getFactorForma() {
        return factorForma;
    }

    public void setFactorForma(String factorForma) {
        this.factorForma = factorForma;
    }
}
