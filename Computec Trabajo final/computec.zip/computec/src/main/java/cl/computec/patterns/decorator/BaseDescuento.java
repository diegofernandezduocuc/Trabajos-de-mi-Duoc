package cl.computec.patterns.decorator;

import java.math.BigDecimal;

public class BaseDescuento implements Descuento {

    @Override
    public BigDecimal aplicar(BigDecimal precioBase) {
        return precioBase;
    }
}
