package cl.computec.model;

public class Laptop extends Equipo {

    private double pantallaPulg;
    private boolean touch;
    private int puertosUsb;

    public Laptop() {
        this.tipo = "laptop";
    }

    public double getPantallaPulg() {
        return pantallaPulg;
    }

    public void setPantallaPulg(double pantallaPulg) {
        this.pantallaPulg = pantallaPulg;
    }

    public boolean isTouch() {
        return touch;
    }

    public void setTouch(boolean touch) {
        this.touch = touch;
    }

    public int getPuertosUsb() {
        return puertosUsb;
    }

    public void setPuertosUsb(int puertosUsb) {
        this.puertosUsb = puertosUsb;
    }
}
