package cl.computec.dao;

import cl.computec.db.DatabaseConnection;
import cl.computec.model.Desktop;
import cl.computec.model.Equipo;
import cl.computec.model.Laptop;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipoDAO {

    public int insertDesktop(String modelo, String cpu, int discoMb, int ramGb, BigDecimal precio,
            int fuenteWatts, String factorForma) throws Exception {
        String sql = "{CALL sp_equipo_insert_desktop(?,?,?,?,?,?,?,?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, modelo);
            cs.setString(2, cpu);
            cs.setInt(3, discoMb);
            cs.setInt(4, ramGb);
            cs.setBigDecimal(5, precio);
            cs.setInt(6, fuenteWatts);
            cs.setString(7, factorForma);
            cs.registerOutParameter(8, Types.INTEGER);
            cs.execute();
            return cs.getInt(8);
        }
    }

    public int insertLaptop(String modelo, String cpu, int discoMb, int ramGb, BigDecimal precio,
            double pantallaPulg, boolean touch, int puertosUsb) throws Exception {
        String sql = "{CALL sp_equipo_insert_laptop(?,?,?,?,?,?,?, ?,?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, modelo);
            cs.setString(2, cpu);
            cs.setInt(3, discoMb);
            cs.setInt(4, ramGb);
            cs.setBigDecimal(5, precio);
            cs.setBigDecimal(6, new BigDecimal(String.valueOf(pantallaPulg)));
            cs.setInt(7, touch ? 1 : 0);
            cs.setInt(8, puertosUsb);
            cs.registerOutParameter(9, Types.INTEGER);
            cs.execute();
            return cs.getInt(9);
        }
    }

    // ===== LISTAR 
    /**
     * Lista por tipo: "desktop" | "laptop" | "todos"/null
     */
    public List<Equipo> listByTipo(String tipo) throws Exception {
        String sql = "{CALL sp_equipo_list(?)}";
        List<Equipo> out = new ArrayList<>();
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, tipo);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    String t = rs.getString("tipo");
                    Equipo e = "desktop".equalsIgnoreCase(t) ? new Desktop() : new Laptop();
                    e.setId(rs.getInt("id"));
                    e.setModelo(rs.getString("modelo"));
                    e.setCpu(rs.getString("cpu"));
                    e.setRamGb(rs.getInt("ram_gb"));
                    e.setDiscoMb(rs.getInt("disco_mb"));
                    e.setPrecio(rs.getBigDecimal("precio"));
                    e.setTipo(t);
                    out.add(e);
                }
            }
        }
        return out;
    }

    // ===== CONSULTAS / ELIMINAR 
    /**
     * ¿Existe el equipo?
     */
    public boolean exists(int idEquipo) throws Exception {
        String sql = "SELECT 1 FROM equipos WHERE id = ? LIMIT 1";
        try (PreparedStatement ps = DatabaseConnection.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * ¿Tiene una venta asociada este equipo?
     */
    public boolean hasVenta(int idEquipo) throws Exception {
        String sql = "SELECT COUNT(*) FROM ventas WHERE id_equipo = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    public void delete(int idEquipo) throws Exception {
        String sql = "DELETE FROM equipos WHERE id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().getConnection().prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            ps.executeUpdate();
        }
    }

    public void deleteCascade(int idEquipo) throws Exception {
        Connection cn = DatabaseConnection.getInstance().getConnection();
        boolean oldAuto = cn.getAutoCommit();
        try {
            cn.setAutoCommit(false);

            try (PreparedStatement ps1 = cn.prepareStatement(
                    "DELETE FROM ventas WHERE id_equipo = ?")) {
                ps1.setInt(1, idEquipo);
                ps1.executeUpdate();
            }
            try (PreparedStatement ps2 = cn.prepareStatement(
                    "DELETE FROM equipos WHERE id = ?")) {
                ps2.setInt(1, idEquipo);
                ps2.executeUpdate();
            }

            cn.commit();
        } catch (Exception ex) {
            cn.rollback();
            throw ex;
        } finally {
            cn.setAutoCommit(oldAuto);
        }
    }
}
