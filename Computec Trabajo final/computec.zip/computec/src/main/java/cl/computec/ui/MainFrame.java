package cl.computec.ui;

import cl.computec.db.DatabaseConnection;
import cl.computec.ui.panel.ClientesPanel;
import cl.computec.ui.panel.EquiposPanel;
import cl.computec.ui.panel.VentasPanel;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class MainFrame extends JFrame {

    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel status = new JLabel("Listo");

    public MainFrame() {
        super("Computec - Proyecto Final");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 680);
        setLocationRelativeTo(null);

        // Menú
        JMenuBar mb = new JMenuBar();
        JMenu mArchivo = new JMenu("Archivo");
        JMenuItem miSalir = new JMenuItem("Salir");
        miSalir.addActionListener(e -> System.exit(0));
        mArchivo.add(miSalir);

        JMenu mVer = new JMenu("Ver");
        JMenuItem miClientes = new JMenuItem("Clientes");
        miClientes.addActionListener(e -> tabs.setSelectedIndex(0));
        JMenuItem miEquipos = new JMenuItem("Equipos");
        miEquipos.addActionListener(e -> tabs.setSelectedIndex(1));
        JMenuItem miVentas = new JMenuItem("Ventas / Reportes");
        miVentas.addActionListener(e -> tabs.setSelectedIndex(2));
        mVer.add(miClientes);
        mVer.add(miEquipos);
        mVer.add(miVentas);

        mb.add(mArchivo);
        mb.add(mVer);
        setJMenuBar(mb);

       
        tabs.addTab("Clientes", new ClientesPanel(status));
        tabs.addTab("Equipos", new EquiposPanel(status));
        tabs.addTab("Ventas / Reportes", new VentasPanel(status));

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(tabs, BorderLayout.CENTER);
        getContentPane().add(status, BorderLayout.SOUTH);

        checkConexion();
    }

    private void checkConexion() {
        try {
            Connection cn = DatabaseConnection.getInstance().getConnection();
            status.setText("Conectado a " + cn.getMetaData().getURL());
            JOptionPane.showMessageDialog(this, "Conexión a MySQL OK", "Conexión",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            status.setText("ERROR: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Conexión", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
