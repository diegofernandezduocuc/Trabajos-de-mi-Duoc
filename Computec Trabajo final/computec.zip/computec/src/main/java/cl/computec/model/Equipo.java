package cl.computec.model;

import java.math.BigDecimal;

public abstract class Equipo {

    protected Integer id;
    protected String modelo;
    protected String cpu;
    protected int discoMb;
    protected int ramGb;
    protected BigDecimal precio;
    protected String tipo; // "desktopp" | "laptop"

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getDiscoMb() {
        return discoMb;
    }

    public void setDiscoMb(int discoMb) {
        this.discoMb = discoMb;
    }

    public int getRamGb() {
        return ramGb;
    }

    public void setRamGb(int ramGb) {
        this.ramGb = ramGb;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
