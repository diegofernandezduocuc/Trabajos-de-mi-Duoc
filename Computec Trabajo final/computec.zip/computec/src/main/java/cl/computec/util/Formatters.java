package cl.computec.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

public class Formatters {

    private static final Locale CL = new Locale("es", "CL");

    public static String clp(BigDecimal value) {
        if (value == null) {
            return "";
        }
        NumberFormat nf = NumberFormat.getCurrencyInstance(CL);
        nf.setMaximumFractionDigits(0);
        nf.setMinimumFractionDigits(0);
        String s = nf.format(value);
       
        if (!s.endsWith("CLP")) {
            s = s + " CLP";
        }
        return s;
    }

    public static String mb(int mb) {
        NumberFormat nf = NumberFormat.getIntegerInstance(CL);
        nf.setGroupingUsed(false); 
        return nf.format(mb) + " (MB)";
    }
}
