package cl.computec.patterns.command;

public class RemoveEquipoCommand implements Command {

    private final Carrito carrito;

    public RemoveEquipoCommand(Carrito c) {
        this.carrito = c;
    }

    @Override
    public void execute() {
        carrito.clear();
    }
}
