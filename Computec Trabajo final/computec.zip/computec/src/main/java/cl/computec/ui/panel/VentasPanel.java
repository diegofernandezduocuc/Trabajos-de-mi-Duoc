package cl.computec.ui.panel;

import cl.computec.dao.ClienteDAO;
import cl.computec.dao.EquipoDAO;
import cl.computec.dao.VentaDAO;
import cl.computec.model.Cliente;
import cl.computec.model.Equipo;
import cl.computec.patterns.command.AddEquipoCommand;
import cl.computec.patterns.command.Carrito;
import cl.computec.patterns.command.RemoveEquipoCommand;
import cl.computec.patterns.decorator.BaseDescuento;
import cl.computec.patterns.decorator.Descuento;
import cl.computec.patterns.decorator.DescuentoPorcentaje;
import cl.computec.util.Formatters;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public class VentasPanel extends JPanel {
    private final JLabel status;

    private final JComboBox<String> cbCliente = new JComboBox<>();
    private final JComboBox<String> cbTipo = new JComboBox<>(new String[]{"todos","desktop","laptop"});
    private final JButton btnCargarEquipos = new JButton("Cargar Equipos");
    private final JTable tblEquipos;
    private final DefaultTableModel modeloEquipos = new DefaultTableModel(
            new Object[]{"ID","Tipo","Modelo","CPU","RAM","Disco","Precio"}, 0) {
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };

    private final JLabel lblSeleccion = new JLabel("Sin equipo en carrito");
    private final JButton btnAgregarCarrito = new JButton("Agregar al carrito");
    private final JButton btnQuitarCarrito = new JButton("Quitar del carrito");

    private final JSpinner spDesc = new JSpinner(new SpinnerNumberModel(0.0, 0.0, 0.9, 0.01));
    private final JButton btnVender = new JButton("Registrar Venta");

    private final JButton btnReporteListado = new JButton("Ver Listado");
    private final JButton btnReporteResumen = new JButton("Ver Resumen");
    private final JTable tblReportes;
    private final DefaultTableModel modeloReportes = new DefaultTableModel(
            new Object[]{"ID Venta","Fecha/Hora","Tipo","ID Equipo","Modelo","Cliente","RUT","Telefono","Email","Precio Final"}, 0) {
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final EquipoDAO equipoDAO = new EquipoDAO();
    private final VentaDAO ventaDAO = new VentaDAO();
    private final Carrito carrito = new Carrito();

    public VentasPanel(JLabel status) {
        this.status = status;
        setLayout(new BorderLayout(6,6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Cliente (RUT): "));
        top.add(cbCliente);
        top.add(new JLabel(" Tipo equipo: "));
        top.add(cbTipo);
        top.add(btnCargarEquipos);

        tblEquipos = new JTable(modeloEquipos);
        tblEquipos.setAutoCreateRowSorter(true);
        // Renderers
        DefaultTableCellRenderer priceR1 = new DefaultTableCellRenderer(){
            @Override protected void setValue(Object value){
                if (value instanceof java.math.BigDecimal) setText(Formatters.clp((java.math.BigDecimal)value));
                else if (value!=null) setText(Formatters.clp(new java.math.BigDecimal(value.toString())));
                else setText("");
            }
        };
        DefaultTableCellRenderer mbR1 = new DefaultTableCellRenderer(){
            @Override protected void setValue(Object value){
                if (value==null) setText(""); else setText(Formatters.mb(Integer.parseInt(value.toString())));
            }
        };
        tblEquipos.getColumnModel().getColumn(5).setCellRenderer(mbR1);
        tblEquipos.getColumnModel().getColumn(6).setCellRenderer(priceR1);

        JPanel carritoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        carritoPanel.add(lblSeleccion);
        carritoPanel.add(btnAgregarCarrito);
        carritoPanel.add(btnQuitarCarrito);
        carritoPanel.add(new JLabel("  Descuento % (0..90): "));
        carritoPanel.add(spDesc);
        carritoPanel.add(btnVender);

        JPanel repTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        repTop.add(new JLabel("Reportes: "));
        repTop.add(btnReporteListado);
        repTop.add(btnReporteResumen);

        tblReportes = new JTable(modeloReportes);
        tblReportes.setAutoCreateRowSorter(true);
        DefaultTableCellRenderer priceR2 = new DefaultTableCellRenderer(){
            @Override protected void setValue(Object value){
                if (value instanceof java.math.BigDecimal) setText(Formatters.clp((java.math.BigDecimal)value));
                else if (value!=null) setText(Formatters.clp(new java.math.BigDecimal(value.toString())));
                else setText("");
            }
        };
        tblReportes.getColumnModel().getColumn(9).setCellRenderer(priceR2);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(tblEquipos), new JScrollPane(tblReportes));
        split.setResizeWeight(0.5);

        add(top, BorderLayout.NORTH);
        add(split, BorderLayout.CENTER);
        add(carritoPanel, BorderLayout.SOUTH);
        add(repTop, BorderLayout.WEST);

        btnCargarEquipos.addActionListener(e -> cargarEquipos());
        btnAgregarCarrito.addActionListener(e -> agregarCarrito());
        btnQuitarCarrito.addActionListener(e -> quitarCarrito());
        btnVender.addActionListener(e -> vender());
        btnReporteListado.addActionListener(e -> reporteListado());
        btnReporteResumen.addActionListener(e -> reporteResumen());

        cargarClientes();
        cargarEquipos();
    }

    private void setStatus(String s){ status.setText(s); }

    private void cargarClientes() {
        try {
            cbCliente.removeAllItems();
            List<Cliente> data = clienteDAO.list();
            for (Cliente c : data) {
                cbCliente.addItem(c.getRut() + " - " + c.getNombre());
            }
            setStatus("Clientes: " + data.size());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void cargarEquipos() {
        try {
            String tipo = (String) cbTipo.getSelectedItem();
            List<Equipo> data = equipoDAO.listByTipo(tipo);
            modeloEquipos.setRowCount(0);
            for (Equipo e : data) {
                modeloEquipos.addRow(new Object[]{
                        e.getId(), e.getTipo(), e.getModelo(), e.getCpu(), e.getRamGb(), e.getDiscoMb(), e.getPrecio()
                });
            }
            setStatus("Equipos cargados: " + data.size());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void agregarCarrito() {
        int row = tblEquipos.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un equipo en la tabla.", "Atención",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int modelRow = tblEquipos.convertRowIndexToModel(row);
        cl.computec.model.Equipo e;
        String tipo = (String) modeloEquipos.getValueAt(modelRow, 1);
        if ("desktop".equalsIgnoreCase(tipo)) e = new cl.computec.model.Desktop();
        else e = new cl.computec.model.Laptop();
        e.setId((Integer) modeloEquipos.getValueAt(modelRow, 0));
        e.setTipo((String) modeloEquipos.getValueAt(modelRow, 1));
        e.setModelo((String) modeloEquipos.getValueAt(modelRow, 2));
        e.setCpu((String) modeloEquipos.getValueAt(modelRow, 3));
        e.setRamGb((Integer) modeloEquipos.getValueAt(modelRow, 4));
        e.setDiscoMb((Integer) modeloEquipos.getValueAt(modelRow, 5));
        Object precioObj = modeloEquipos.getValueAt(modelRow, 6);
        BigDecimal precio = (precioObj instanceof BigDecimal)
                ? (BigDecimal) precioObj
                : new BigDecimal(precioObj.toString());
        e.setPrecio(precio);

        new AddEquipoCommand(carrito, e).execute();
        lblSeleccion.setText("Carrito: ID " + e.getId() + " - " + e.getModelo() + " (" + Formatters.clp(e.getPrecio()) + ")");
        setStatus("Equipo agregado al carrito.");
    }

    private void quitarCarrito() {
        new RemoveEquipoCommand(carrito).execute();
        lblSeleccion.setText("Sin equipo en carrito");
        setStatus("Carrito vacío.");
    }

    private void vender() {
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay equipo en carrito.", "Atención",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (cbCliente.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "No hay cliente seleccionado.", "Atención",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        String rut = cbCliente.getSelectedItem().toString().split(" - ")[0];
        Equipo e = carrito.getEquipo();

        try {
            // Validaciones ANTES de registrar la venta
            if (!equipoDAO.exists(e.getId())) {
                JOptionPane.showMessageDialog(this,
                        "El equipo seleccionado ya no existe (posiblemente fue eliminado).\n" +
                        "Se recargará la lista.", "No encontrado",
                        JOptionPane.WARNING_MESSAGE);
                cargarEquipos();
                quitarCarrito();
                return;
            }
            if (equipoDAO.hasVenta(e.getId())) {
                JOptionPane.showMessageDialog(this,
                        "Ese equipo ya fue vendido. Debes seleccionar otro.",
                        "Equipo vendido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double pct = ((Number) spDesc.getValue()).doubleValue(); // 0..0.9
            Descuento d = new DescuentoPorcentaje(new BaseDescuento(), new BigDecimal(String.valueOf(pct)));

            int idVenta = ventaDAO.insertarVenta(rut, e, d);
            JOptionPane.showMessageDialog(this, "Venta registrada. ID: " + idVenta);
            setStatus("Venta OK id=" + idVenta);
            reporteResumen();     // refresca resumen
            cargarEquipos();      // refresca stock
            quitarCarrito();      // limpia carrito
        } catch (SQLIntegrityConstraintViolationException ex) {
           
            JOptionPane.showMessageDialog(this,
                    "No se pudo registrar la venta por una restricción de integridad.\n" +
                    "Verifica que el equipo exista y no esté ya vendido.",
                    "Restricción de integridad", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            String msg = ex.getMessage() != null ? ex.getMessage().toLowerCase() : "";
            if (msg.contains("foreign key")) {
                JOptionPane.showMessageDialog(this,
                        "No se pudo registrar la venta: el equipo ya no existe.\n" +
                        "Recarga la lista y selecciona otro.",
                        "FK falló", JOptionPane.ERROR_MESSAGE);
            } else if (msg.contains("duplicate") || msg.contains("uq_vta_equipo") || msg.contains("unique")) {
                JOptionPane.showMessageDialog(this,
                        "Ese equipo ya fue vendido (único por venta).",
                        "Equipo vendido", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void reporteListado() {
        try {
            String tipo = (String) cbTipo.getSelectedItem();
            List<Object[]> rows = ventaDAO.reporteListado(tipo);
            modeloReportes.setRowCount(0);
            for (Object[] r : rows) modeloReportes.addRow(r);
            setStatus("Reporte listado: " + rows.size() + " filas.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void reporteResumen() {
        try {
            VentaDAO.Resumen r = ventaDAO.reporteResumen();
            JOptionPane.showMessageDialog(this, "Ventas: " + r.cantidad + "  |  Total: " + Formatters.clp(r.total));
            setStatus("Resumen actualizado. Ventas=" + r.cantidad + " Total=" + Formatters.clp(r.total));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }
}