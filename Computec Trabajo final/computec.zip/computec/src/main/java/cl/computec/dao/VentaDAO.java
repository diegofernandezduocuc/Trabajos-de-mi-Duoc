package cl.computec.dao;

import cl.computec.db.DatabaseConnection;
import cl.computec.model.Equipo;
import cl.computec.patterns.decorator.Descuento;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    public int insertarVenta(String rutCliente, Equipo equipo, Descuento descuento) throws Exception {
        BigDecimal precioBase = equipo.getPrecio();
        BigDecimal precioFinal = descuento.aplicar(precioBase);

        String sql = "{CALL sp_venta_insert(?,?,?,?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, rutCliente);
            cs.setInt(2, equipo.getId());
            cs.setBigDecimal(3, precioFinal);
            cs.registerOutParameter(4, Types.INTEGER);
            cs.execute();
            return cs.getInt(4);
        }
    }

    public static class Resumen {

        public int cantidad;
        public BigDecimal total;
    }

    public List<Object[]> reporteListado(String tipo) throws Exception {
        String sql = "{CALL sp_reporte_listado(?)}";
        List<Object[]> rows = new ArrayList<>();
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, tipo);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{
                        rs.getInt("id_venta"),
                        rs.getTimestamp("fecha_hora"),
                        rs.getString("tipo"),
                        rs.getInt("id"),
                        rs.getString("modelo"),
                        rs.getString("cliente"),
                        rs.getString("rut"),
                        rs.getString("telefono"),
                        rs.getString("email"),
                        rs.getBigDecimal("precio_final")
                    });
                }
            }
        }
        return rows;
    }

    public Resumen reporteResumen() throws Exception {
        String sql = "{CALL sp_reporte_resumen()}";
        Resumen r = new Resumen();
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql); ResultSet rs = cs.executeQuery()) {
            if (rs.next()) {
                r.cantidad = rs.getInt("cantidad");
                r.total = rs.getBigDecimal("total");
            }
        }
        return r;
    }
}
