package cl.computec.ui.panel;

import cl.computec.dao.ClienteDAO;
import cl.computec.model.Cliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.regex.Pattern;

public class ClientesPanel extends JPanel {

    private final JLabel status;

    
    private final JTextField txtRut = new JTextField(12);
    private final JTextField txtNombre = new JTextField(24);
    private final JTextField txtDireccion = new JTextField(24);
    private final JTextField txtComuna = new JTextField(16);
    private final JTextField txtEmail = new JTextField(20);
    private final JTextField txtTelefono = new JTextField(16);

   
    private final JButton btnNuevo = new JButton("Nuevo");
    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnBuscar = new JButton("Buscar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnListar = new JButton("Listar");
    private final JButton btnLimpiar = new JButton("Limpiar");

    // Table
    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"RUT", "Nombre", "Direccion", "Comuna", "Email", "Telefono"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modelo);

    private final ClienteDAO dao = new ClienteDAO();

    public ClientesPanel(JLabel status) {
        this.status = status;
        setLayout(new BorderLayout(6, 6));

        
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0;
        c.gridy = 0;
        form.add(new JLabel("RUT"), c);
        c.gridx = 1;
        form.add(txtRut, c);

        c.gridx = 0;
        c.gridy = 1;
        form.add(new JLabel("Nombre"), c);
        c.gridx = 1;
        form.add(txtNombre, c);

        c.gridx = 0;
        c.gridy = 2;
        form.add(new JLabel("Direccion"), c);
        c.gridx = 1;
        form.add(txtDireccion, c);

        c.gridx = 0;
        c.gridy = 3;
        form.add(new JLabel("Comuna"), c);
        c.gridx = 1;
        form.add(txtComuna, c);

        c.gridx = 0;
        c.gridy = 4;
        form.add(new JLabel("Email"), c);
        c.gridx = 1;
        form.add(txtEmail, c);

        c.gridx = 0;
        c.gridy = 5;
        form.add(new JLabel("Telefono"), c);
        c.gridx = 1;
        form.add(txtTelefono, c);

      
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        acciones.add(btnNuevo);
        acciones.add(btnGuardar);
        acciones.add(btnBuscar);
        acciones.add(btnActualizar);
        acciones.add(btnEliminar);
        acciones.add(btnListar);
        acciones.add(btnLimpiar);

   
        tabla.setAutoCreateRowSorter(true);
        JScrollPane sp = new JScrollPane(tabla);

       
        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.CENTER);
        north.add(acciones, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

       
        btnNuevo.setToolTipText("Vaciar el formulario");
        btnGuardar.setToolTipText("Insertar cliente (SP)");
        btnBuscar.setToolTipText("Buscar por RUT (SP)");
        btnActualizar.setToolTipText("Actualizar cliente (SP)");
        btnEliminar.setToolTipText("Eliminar por RUT (SP)");
        btnListar.setToolTipText("Listar todos (SP)");
        btnLimpiar.setToolTipText("Limpiar selección de la tabla");

       
        btnNuevo.addActionListener(e -> limpiarCampos());
        btnLimpiar.addActionListener(e -> {
            tabla.clearSelection();
            limpiarCampos();
        });
        btnListar.addActionListener(e -> listar());
        btnGuardar.addActionListener(e -> guardar());
        btnBuscar.addActionListener(e -> buscar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());

       
        listar();
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    private void limpiarCampos() {
        txtRut.setText("");
        txtNombre.setText("");
        txtDireccion.setText("");
        txtComuna.setText("");
        txtEmail.setText("");
        txtTelefono.setText("");
        txtRut.requestFocus();
    }

    private boolean validar() {
        if (txtRut.getText().trim().isEmpty()
                || txtNombre.getText().trim().isEmpty()
                || txtDireccion.getText().trim().isEmpty()
                || txtComuna.getText().trim().isEmpty()
                || txtEmail.getText().trim().isEmpty()
                || txtTelefono.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.", "Validacion",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }
        String email = txtEmail.getText().trim();
        if (!Pattern.compile(".+@.+\\..+").matcher(email).matches()) {
            JOptionPane.showMessageDialog(this, "Email no válido.", "Validacion",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private Cliente fromForm() {
        Cliente c = new Cliente();
        c.setRut(txtRut.getText().trim());
        c.setNombre(txtNombre.getText().trim());
        c.setDireccion(txtDireccion.getText().trim());
        c.setComuna(txtComuna.getText().trim());
        c.setEmail(txtEmail.getText().trim());
        c.setTelefono(txtTelefono.getText().trim());
        return c;
    }

    private void toForm(Cliente c) {
        txtRut.setText(c.getRut());
        txtNombre.setText(c.getNombre());
        txtDireccion.setText(c.getDireccion());
        txtComuna.setText(c.getComuna());
        txtEmail.setText(c.getEmail());
        txtTelefono.setText(c.getTelefono());
    }

    private void guardar() {
        if (!validar()) {
            return;
        }
        try {
            dao.insert(fromForm());
            JOptionPane.showMessageDialog(this, "Cliente insertado.");
            listar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void buscar() {
        String rut = txtRut.getText().trim();
        if (rut.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa RUT para buscar.", "Atencion",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Cliente c = dao.get(rut);
            if (c == null) {
                JOptionPane.showMessageDialog(this, "No encontrado.");
            } else {
                toForm(c);
                setStatus("Encontrado " + rut);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void actualizar() {
        if (!validar()) {
            return;
        }
        try {
            dao.update(fromForm());
            JOptionPane.showMessageDialog(this, "Actualizado.");
            listar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void eliminar() {
        String rut = txtRut.getText().trim();
        if (rut.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa RUT para eliminar.", "Atencion",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "Eliminar RUT " + rut + "?", "Confirmar",
                JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            dao.delete(rut);
            JOptionPane.showMessageDialog(this, "Eliminado.");
            listar();
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            List<Cliente> data = dao.list();
            modelo.setRowCount(0);
            for (Cliente c : data) {
                modelo.addRow(new Object[]{
                    c.getRut(), c.getNombre(), c.getDireccion(), c.getComuna(), c.getEmail(), c.getTelefono()
                });
            }
            setStatus("Listados: " + data.size());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            setStatus("ERROR: " + ex.getMessage());
        }
    }
}
