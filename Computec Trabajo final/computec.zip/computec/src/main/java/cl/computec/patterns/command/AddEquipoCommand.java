package cl.computec.patterns.command;

import cl.computec.model.Equipo;

public class AddEquipoCommand implements Command {

    private final Carrito carrito;
    private final Equipo equipo;

    public AddEquipoCommand(Carrito c, Equipo e) {
        this.carrito = c;
        this.equipo = e;
    }

    @Override
    public void execute() {
        carrito.setEquipo(equipo);
    }
}
