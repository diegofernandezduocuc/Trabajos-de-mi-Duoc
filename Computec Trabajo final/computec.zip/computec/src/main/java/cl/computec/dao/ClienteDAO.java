package cl.computec.dao;

import cl.computec.db.DatabaseConnection;
import cl.computec.model.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    public void insert(Cliente c) throws Exception {
        String sql = "{CALL sp_cliente_insert(?,?,?,?,?,?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, c.getRut());
            cs.setString(2, c.getNombre());
            cs.setString(3, c.getDireccion());
            cs.setString(4, c.getComuna());
            cs.setString(5, c.getEmail());
            cs.setString(6, c.getTelefono());
            cs.execute();
        }
    }

    public void update(Cliente c) throws Exception {
        String sql = "{CALL sp_cliente_update(?,?,?,?,?,?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, c.getRut());
            cs.setString(2, c.getNombre());
            cs.setString(3, c.getDireccion());
            cs.setString(4, c.getComuna());
            cs.setString(5, c.getEmail());
            cs.setString(6, c.getTelefono());
            cs.execute();
        }
    }

    public void delete(String rut) throws Exception {
        String sql = "{CALL sp_cliente_delete(?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, rut);
            cs.execute();
        }
    }

    public Cliente get(String rut) throws Exception {
        String sql = "{CALL sp_cliente_get(?)}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql)) {
            cs.setString(1, rut);
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    Cliente c = new Cliente();
                    c.setRut(rs.getString("rut"));
                    c.setNombre(rs.getString("nombre"));
                    c.setDireccion(rs.getString("direccion"));
                    c.setComuna(rs.getString("comuna"));
                    c.setEmail(rs.getString("email"));
                    c.setTelefono(rs.getString("telefono"));
                    return c;
                }
            }
        }
        return null;
    }

    public List<Cliente> list() throws Exception {
        List<Cliente> out = new ArrayList<>();
        String sql = "{CALL sp_cliente_list()}";
        try (CallableStatement cs = DatabaseConnection.getInstance().getConnection().prepareCall(sql); ResultSet rs = cs.executeQuery()) {
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setRut(rs.getString("rut"));
                c.setNombre(rs.getString("nombre"));
                c.setDireccion(rs.getString("direccion"));
                c.setComuna(rs.getString("comuna"));
                c.setEmail(rs.getString("email"));
                c.setTelefono(rs.getString("telefono"));
                out.add(c);
            }
        }
        return out;
    }
}
