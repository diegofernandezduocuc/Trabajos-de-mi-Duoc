package cl.computec.patterns.decorator;

import java.math.BigDecimal;

public interface Descuento {

    BigDecimal aplicar(BigDecimal precioBase);
}
