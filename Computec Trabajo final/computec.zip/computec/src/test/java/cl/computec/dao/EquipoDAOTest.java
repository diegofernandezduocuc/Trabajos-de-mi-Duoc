package cl.computec.dao;

import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;

public class EquipoDAOTest {

    @Test
    public void testInsertDesktopYLaptop() throws Exception {
        EquipoDAO dao = new EquipoDAO();
        int idD = dao.insertDesktop("JUnitDesk-" + System.currentTimeMillis(), "i5", 256000, 8, new BigDecimal("399990"), 450, "microatx");
        int idL = dao.insertLaptop("JUnitLap-" + System.currentTimeMillis(), "Ryzen 5", 512000, 16, new BigDecimal("599990"), 15.6, false, 3);
        assertTrue(idD > 0);
        assertTrue(idL > 0);
        assertTrue(dao.listByTipo("desktop").size() > 0);
        assertTrue(dao.listByTipo("laptop").size() > 0);
    }
}
