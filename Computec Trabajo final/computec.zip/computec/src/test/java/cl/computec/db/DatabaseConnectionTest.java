package cl.computec.db;

import org.junit.Test;
import static org.junit.Assert.*;

public class DatabaseConnectionTest {

    @Test
    public void testConexionNoNula() {
        assertNotNull(DatabaseConnection.getInstance().getConnection());
    }
}
