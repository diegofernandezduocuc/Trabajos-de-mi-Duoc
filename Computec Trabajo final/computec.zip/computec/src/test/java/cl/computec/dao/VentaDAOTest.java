package cl.computec.dao;

import cl.computec.model.Desktop;
import cl.computec.model.Equipo;
import cl.computec.patterns.decorator.BaseDescuento;
import cl.computec.patterns.decorator.Descuento;
import cl.computec.patterns.decorator.DescuentoPorcentaje;
import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;

public class VentaDAOTest {

    @Test
    public void testInsertarVentaConDescuento() throws Exception {
        // Prepara un equipo básico
        EquipoDAO eDao = new EquipoDAO();
        int id = eDao.insertDesktop("JUnitVenta-" + System.currentTimeMillis(), "i3", 256000, 8, new BigDecimal("299990"), 400, "atx");

        // Mapea equipo minimo
        Equipo e = new Desktop();
        e.setId(id);
        e.setModelo("JUnitVenta");
        e.setCpu("i3");
        e.setDiscoMb(256000);
        e.setRamGb(8);
        e.setPrecio(new BigDecimal("299990"));
        e.setTipo("desktop");

        // Descuento 10%
        Descuento d = new DescuentoPorcentaje(new BaseDescuento(), new BigDecimal("0.10"));

        VentaDAO vDao = new VentaDAO();
        // Usa un cliente de la semilla '11.111.111-11'
        int idVenta = vDao.insertarVenta("11.111.111-1", e, d);
        assertTrue(idVenta > 0);
    }
}
