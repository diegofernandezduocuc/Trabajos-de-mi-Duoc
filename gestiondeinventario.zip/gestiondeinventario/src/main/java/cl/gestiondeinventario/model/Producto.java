package cl.gestiondeinventario.model;
import cl.gestiondeinventario.exceptions.ValidacionException;
import java.util.Objects;

public class Producto {
    //  TODO: entidad de dominio (codigo unico, nombre, precio, stock)
    private String codigo;
    private String nombre;
    private double precio;
    private int stock;

    // TODO: centralizar  validaciones n setters
    public Producto(String codigo, String nombre, double precio, int stock) {
        setCodigo(codigo);
        setNombre(nombre);
        setPrecio(precio);
        setStock(stock);
    }

    public String getCodigo() { return codigo; }

    // TODO: normalizar y validar codigo (no vacio)
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new ValidacionException("El codigo no puede ser vacio");
        }
        this.codigo = codigo.trim();
    }

    public String getNombre() { return nombre; }

     // TODO: normalizar y validar nombre (no vacio)
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new ValidacionException("El nombre no puede ser vacio");
        }
        this.nombre = nombre.trim();
    }

    public double getPrecio() { return precio; }

    // TODO: evitar precios negativos
    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new ValidacionException("El precio no puede ser negativo");
        }
        this.precio = precio;
    }

    public int getStock() { return stock; }

    // TODO:  evitar stock  negativo
    public void setStock(int stock) {
        if (stock < 0) {
            throw new ValidacionException("El stock no puede ser negativo");
        }
        this.stock = stock;
    }

    // TODO: actualizar precio usando  la misma validacion
    public void actualizarPrecio(double nuevoPrecio) {
        setPrecio(nuevoPrecio);
    }

    // TODO: descripcion  util para informes y debugging
    public String descripcionDetallada() {
        return "Producto{codigo='" + codigo + "', nombre='" + nombre + "', precio=" + precio + ", stock=" + stock + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Producto)) return false;
        Producto producto = (Producto) o;
        return Objects.equals(codigo, producto.codigo);
    }

    @Override
    public int hashCode() { return Objects.hash(codigo); }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " ($" + precio + ", stock: " + stock + ")";
    }
}