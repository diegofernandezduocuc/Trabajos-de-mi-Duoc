 package cl.gestiondeinventario.model;

import cl.gestiondeinventario.exceptions.CodigoDuplicadoException;
import cl.gestiondeinventario.exceptions.ProductoNoEncontradoException;
import cl.gestiondeinventario.exceptions.StockInvalidoException;
import cl.gestiondeinventario.exceptions.ValidacionException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class Inventario {
    //  TODo: repositorio en memoria  (clave =  codigo)
    private final Map<String, Producto> productos;

    public Inventario() {
        this.productos = new HashMap<>();
    }

     // TODO: asegurar codigo unico por producto
    public void agregarProducto(Producto producto) {
        if (producto == null) throw new ValidacionException("Producto nulo");
        String codigo = producto.getCodigo();
        if (productos.containsKey(codigo)) {
             throw new CodigoDuplicadoException("Ya existe un producto con codigo: " + codigo);
        }
        productos.put(codigo, producto);
    }

    // TODO: buscar por codigo (null si no existe)
    public Producto buscarPorCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) return null;
        return productos.get(codigo.trim());
    }

    // TODO: buscar por nombre (contiene, case-insensitive)
    public List<Producto> buscarPorNombre(String patron) {
        if (patron == null) patron = "";
        String p = patron.trim().toLowerCase();
        List<Producto> lista = new ArrayList<>();
        for (Producto prod : productos.values()) {
            if (prod.getNombre().toLowerCase().contains(p)) {
                lista.add(prod);
            }
        }
        lista.sort(Comparator.comparing(Producto::getNombre));
        return lista;
    }

     // TODO: listar ordenado por nombre
    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>(productos.values());
        lista.sort(Comparator.comparing(Producto::getNombre));
        return lista;
    }

    // TODO: actualizar precio (error si no existe)
    public void actualizarPrecio(String codigo, double nuevoPrecio) {
        Producto p = buscarPorCodigo(codigo);
        if (p == null) throw new ProductoNoEncontradoException("No encontrado: " + codigo);
        p.actualizarPrecio(nuevoPrecio);
    }

    // TODO: actualizar stock (suma/resta)  evitando negativo
    public void actualizarStock(String codigo, int delta) {
         Producto p = buscarPorCodigo(codigo);
        if (p == null) throw new ProductoNoEncontradoException("No encontrado: " + codigo);
        int nuevo = p.getStock() + delta;
        if (nuevo < 0) throw new StockInvalidoException("Stock resultante negativo");
        p.setStock(nuevo);
    }

    // TODO: generar informe simple
    public String generarInforme() {
        int totalProductos = productos.size();
        long totalUnidades = 0;
        double valorInventario = 0.0;
        for (Producto p : productos.values()) {
            totalUnidades += p.getStock();
            valorInventario += p.getPrecio() * p.getStock();
        }

        List<Producto> topStock = new ArrayList<>(productos.values());
        topStock.sort(Comparator.comparingInt(Producto::getStock).reversed());
        if (topStock.size() > 3) topStock = topStock.subList(0, 3);

        StringBuilder sb = new StringBuilder();
        sb.append("=== INFORME DE INVENTARIO ===\n");
        sb.append("Total de productos distintos: ").append(totalProductos).append("\n");
        sb.append("Total de unidades: ").append(totalUnidades).append("\n");
        sb.append("Valor total (precio x stock): ").append(String.format("%.2f", valorInventario)).append("\n");
        sb.append("Top 3 por stock:\n");
        for (Producto p : topStock) {
            sb.append(" - ").append(p.toString()).append("\n");
        }
        return sb.toString();
    }
}