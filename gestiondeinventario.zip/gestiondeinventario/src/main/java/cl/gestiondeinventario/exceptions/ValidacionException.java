package cl.gestiondeinventario.exceptions;

// TODO: excepcion de validacion de datos (campos vacios, negativos, etc.)
public class ValidacionException extends RuntimeException {
    public ValidacionException(String message) { super(message); }
}