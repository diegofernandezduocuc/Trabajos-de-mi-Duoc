package cl.gestiondeinventario.exceptions;

// TODO: se lanza cuando el codigo de producto ya existe
public class CodigoDuplicadoException extends RuntimeException {
    public CodigoDuplicadoException(String message) { super(message); }
}