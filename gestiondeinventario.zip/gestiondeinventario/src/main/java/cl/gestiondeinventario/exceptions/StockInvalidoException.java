package cl.gestiondeinventario.exceptions;

// TODO: stock resultante invalido (negativo) u operaciones de stock no permitidas
public class StockInvalidoException extends RuntimeException {
    public StockInvalidoException(String message) { super(message); }
}