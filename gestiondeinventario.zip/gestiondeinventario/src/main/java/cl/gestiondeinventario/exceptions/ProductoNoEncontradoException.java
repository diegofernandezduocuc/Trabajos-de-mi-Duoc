package cl.gestiondeinventario.exceptions;

// TODO: se usa cuando no se encuentra un producto por codigo
public class ProductoNoEncontradoException extends RuntimeException {
    public ProductoNoEncontradoException(String message) { super(message); }
}