package cl.gestiondeinventario.ui;
import cl.gestiondeinventario.exceptions.ValidacionException;
import cl.gestiondeinventario.exceptions.CodigoDuplicadoException;
import cl.gestiondeinventario.exceptions.ProductoNoEncontradoException;
import cl.gestiondeinventario.exceptions.StockInvalidoException;
import cl.gestiondeinventario.model.Inventario;
import cl.gestiondeinventario.model.Producto;
import cl.gestiondeinventario.storage.InventarioCsvStorage;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class MenuPrincipal {

    // TODO: ruta del CSV (se  crea carpeta data/ en la raiz del proyecto)
    private static final String RUTA_CSV = "data/inventario.csv";

    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        InventarioCsvStorage storage = new InventarioCsvStorage(RUTA_CSV);

        // TODO:  cargar desde CSV; si no hay datos, precargar ejemplos y guardar
        try {
            storage.cargarEn(inventario);
            if (inventario.listar().isEmpty()) {
                precargarDatos(inventario);
                storage.guardar(inventario);
            }
        } catch (IOException e) {
            System.out.println("Aviso: no se pudo cargar/guardar CSV: " + e.getMessage());
        }

        Scanner sc = new Scanner(System.in);
        int opcion = -1;

        do {
            mostrarMenu();
            try {
                System.out.print("Elige una opcion: ");
                String entrada = sc.nextLine().trim();
                opcion = Integer.parseInt(entrada);

                switch (opcion) {
                    case 1 -> agregarProducto(sc, inventario, storage);
                    case 2 -> buscarPorCodigo(sc, inventario);
                    case 3 -> listar(inventario);
                    case 4 -> actualizarPrecio(sc, inventario, storage);
                    case 5 -> actualizarStock(sc, inventario, storage);
                    case 6 -> generarInforme(inventario);
                    case 0 -> {
                        // TODO:  guardar al salir por  seguridad
                        try { storage.guardar(inventario); } catch (IOException e) {
                            System.out.println("Aviso: no se pudo guardar al salir: " + e.getMessage());
                        }
                        System.out.println("Saliendo...");
                    }
                    default -> System.out.println("Opcion no valida");
                }
            } catch (ValidacionException | CodigoDuplicadoException |
                     ProductoNoEncontradoException | StockInvalidoException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Entrada invalida, intenta de nuevo.");
            } catch (Exception e) {
                System.out.println("Error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println("\n=== GESTION DE INVENTARIO ===");
        System.out.println("1) Agregar producto");
        System.out.println("2) Buscar por codigo");
        System.out.println("3) Listar productos");
        System.out.println("4) Actualizar precio");
        System.out.println("5) Actualizar stock (+/-)");
        System.out.println("6) Generar informe");
        System.out.println("0) Salir");
    }

    private static void precargarDatos(Inventario inventario) {
        inventario.agregarProducto(new Producto("P-100", "Cables UTP Cat6", 2990, 50));
        inventario.agregarProducto(new Producto("P-200", "Conector RJ45", 150, 300));
        inventario.agregarProducto(new Producto("P-300", "Tester de red", 18990, 10));
    }

    private static void agregarProducto(Scanner sc, Inventario inventario, InventarioCsvStorage storage) {
        System.out.print("Codigo: ");
        String codigo = sc.nextLine();
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Precio: ");
        double precio = Double.parseDouble(sc.nextLine().trim());
        System.out.print("Stock: ");
        int stock = Integer.parseInt(sc.nextLine().trim());

        Producto p = new Producto(codigo, nombre, precio, stock);
        inventario.agregarProducto(p);
        System.out.println("Producto agregado.");
        try { storage.guardar(inventario); } catch (IOException e) {
            System.out.println("Aviso: no se pudo guardar: " + e.getMessage());
        }
    }

    private static void buscarPorCodigo(Scanner sc, Inventario inventario) {
        System.out.print("Codigo a buscar: ");
        String codigo = sc.nextLine();
        Producto p = inventario.buscarPorCodigo(codigo);
        if (p == null) {
            System.out.println("No existe un producto con ese codigo.");
        } else {
            System.out.println("Encontrado: " + p.descripcionDetallada());
        }
    }

    private static void listar(Inventario inventario) {
        List<Producto> lista = inventario.listar();
        if (lista.isEmpty()) {
            System.out.println("No hay productos.");
        } else {
            System.out.println("=== LISTA DE PRODUCTOS ===");
            for (Producto p : lista) {
                System.out.println(p);
            }
        }
    }

    private static void actualizarPrecio(Scanner sc, Inventario inventario, InventarioCsvStorage storage) {
        System.out.print("Codigo: ");
        String codigo = sc.nextLine();
        System.out.print("Nuevo precio: ");
        double precio = Double.parseDouble(sc.nextLine().trim());
        inventario.actualizarPrecio(codigo, precio);
        System.out.println("Precio actualizado.");
        try { storage.guardar(inventario); } catch (IOException e) {
            System.out.println("Aviso: no se pudo guardar: " + e.getMessage());
        }
    }

    private static void actualizarStock(Scanner sc, Inventario inventario, InventarioCsvStorage storage) {
        System.out.print("Codigo: ");
        String codigo = sc.nextLine();
        System.out.print("Delta de stock (ej: 5 o -3): ");
        int delta = Integer.parseInt(sc.nextLine().trim());
        inventario.actualizarStock(codigo, delta);
        System.out.println("Stock actualizado.");
        try { storage.guardar(inventario); } catch (IOException e) {
            System.out.println("Aviso: no se pudo guardar: " + e.getMessage());
        }
    }

    private static void generarInforme(Inventario inventario) {
        String informe = inventario.generarInforme();
        System.out.println(informe);
    }
}