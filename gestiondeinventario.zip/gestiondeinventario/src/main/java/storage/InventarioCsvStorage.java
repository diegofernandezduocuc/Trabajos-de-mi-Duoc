package cl.gestiondeinventario.storage;

import cl.gestiondeinventario.model.Inventario;
import cl.gestiondeinventario.model.Producto;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

// TODO: persistencia simple en CSV (codigo;nombre;precio;stock) en carpeta data/
public class InventarioCsvStorage {

    private static final String HEADER = "codigo;nombre;precio;stock";
    private static final String SEP = ";";
    private final Path file;

    public InventarioCsvStorage(String relativePath) {
        this.file = Paths.get(relativePath);
    }

    // TODO: guarda el inventario completo en CSV
    public void guardar(Inventario inventario) throws IOException {
        Path parent = file.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        try (BufferedWriter bw = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            bw.write(HEADER);
            bw.newLine();
            for (Producto p : inventario.listar()) {
                String linea = String.join(SEP,
                        safe(p.getCodigo()),
                        safe(p.getNombre()),
                        Double.toString(p.getPrecio()),
                        Integer.toString(p.getStock()));
                bw.write(linea);
                bw.newLine();
            }
        }
    }

    // TODO: carga los productos del CSV (si existen) dentro del inventario
    public void cargarEn(Inventario inventario) throws IOException {
        if (!Files.exists(file)) return;
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String linea;
            boolean primera = true;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                if (primera) { // saltar encabezado si corresponde
                    primera = false;
                    if (linea.toLowerCase().startsWith("codigo" + SEP)) continue;
                }
                String[] cols = linea.split(SEP, -1);
                if (cols.length < 4) continue;
                String codigo = cols[0].trim();
                String nombre = cols[1].trim();
                double precio = parseDouble(cols[2].trim(), 0.0);
                int stock = parseInt(cols[3].trim(), 0);

                Producto existente = inventario.buscarPorCodigo(codigo);
                if (existente == null) {
                    inventario.agregarProducto(new Producto(codigo, nombre, precio, stock));
                } else {
                    // TODO: actualizar datos si ya existia
                    existente.setNombre(nombre);
                    existente.setPrecio(precio);
                    existente.setStock(stock);
                }
            }
        }
    }

    private static String safe(String s) {
        if (s == null) return "";
        // reemplazar separadores o saltos de linea para mantener CSV simple
        return s.replace(SEP, ",").replace("\r", " ").replace("\n", " ").trim();
    }

    private static double parseDouble(String s, double def) {
        try { return Double.parseDouble(Objects.toString(s, "")); } catch (Exception e) { return def; }
    }

    private static int parseInt(String s, int def) {
        try { return Integer.parseInt(Objects.toString(s, "")); } catch (Exception e) { return def; }
    }
}