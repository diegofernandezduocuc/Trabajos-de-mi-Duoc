package cl.gestiondeinventario.model;

import cl.gestiondeinventario.exceptions.ValidacionException;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductoTest {

    @Test
    public void testActualizarPrecio() {
        Producto p = new Producto("X1", "Item", 1000, 5);
        p.actualizarPrecio(1990);
        assertEquals(1990, p.getPrecio(), 0.01);
    }

    @Test(expected = ValidacionException.class)
    public void testPrecioNegativoLanzaExcepcion() {
        new Producto("X2", "Item", -10, 0);
    }

    @Test
    public void testDescripcionDetalladaNoVacia() {
        Producto p = new Producto("X3", "Item", 500, 2);
        assertTrue(p.descripcionDetallada().contains("X3"));
    }
}