package cl.gestiondeinventario.model;

import cl.gestiondeinventario.exceptions.CodigoDuplicadoException;
import cl.gestiondeinventario.exceptions.StockInvalidoException;
import org.junit.Test;
import static org.junit.Assert.*;

public class InventarioTest {

    @Test
    public void testAgregarYBuscar() {
        Inventario inv = new Inventario();
        Producto p = new Producto("A1", "Articulo A", 100, 1);
        inv.agregarProducto(p);
        assertNotNull(inv.buscarPorCodigo("A1"));
    }

    @Test(expected = CodigoDuplicadoException.class)
    public void testAgregarDuplicadoLanzaExcepcion() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto("A1", "Articulo A", 100, 1));
        inv.agregarProducto(new Producto("A1", "Articulo A", 100, 1));
    }

    @Test(expected = StockInvalidoException.class)
    public void testActualizarStockNoPermiteNegativo() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto("B1", "B", 10, 1));
        inv.actualizarStock("B1", -2);
    }
}