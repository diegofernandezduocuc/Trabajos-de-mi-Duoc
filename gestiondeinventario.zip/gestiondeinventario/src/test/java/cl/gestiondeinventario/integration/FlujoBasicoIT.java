package cl.gestiondeinventario.integration;

import cl.gestiondeinventario.model.Inventario;
import cl.gestiondeinventario.model.Producto;
import org.junit.Test;
import static org.junit.Assert.*;

public class FlujoBasicoIT {

    @Test
    public void testFlujoCompleto() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto("C1", "Cable", 2000, 10));
        inv.actualizarPrecio("C1", 2490);
        inv.actualizarStock("C1", -2);

        Producto p = inv.buscarPorCodigo("C1");
        assertNotNull(p);
        assertEquals(2490, p.getPrecio(), 0.01);
        assertEquals(8, p.getStock());
        assertTrue(inv.generarInforme().contains("INFORME"));
    }
}