package cl.magentacine.ui;

import cl.magentacine.model.Pelicula;

import javax.swing.*;
import java.awt.*;

public class PeliculaFormDialog extends JDialog {

    private final JTextField txtTitulo = new JTextField(24);
    private final JTextField txtDirector = new JTextField(24);
    private final JSpinner spAnio = new JSpinner(
            new SpinnerNumberModel(java.time.Year.now().getValue(), 1888, java.time.Year.now().getValue(), 1)
    );
    private final JSpinner spDuracion = new JSpinner(new SpinnerNumberModel(90, 1, 1000, 1));
    private final JComboBox<String> cbGenero = new JComboBox<>(new String[]{
        "Accion", "Comedia", "Drama", "Romance", "Terror", "Suspenso", "Animacion", "Documental"
    });

    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnLimpiar = new JButton("Limpiar");
    private final JButton btnCancelar = new JButton("Cancelar");

    private Pelicula resultado;
    private boolean confirmado = false;

    public PeliculaFormDialog(Window owner) {
        super(owner, "Agregar Pelicula", ModalityType.APPLICATION_MODAL);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0;
        c.gridy = 0;
        form.add(new JLabel("Titulo"), c);
        c.gridx = 1;
        form.add(txtTitulo, c);

        c.gridx = 0;
        c.gridy = 1;
        form.add(new JLabel("Director"), c);
        c.gridx = 1;
        form.add(txtDirector, c);

        c.gridx = 0;
        c.gridy = 2;
        form.add(new JLabel("Anio"), c);
        c.gridx = 1;
        form.add(spAnio, c);

        c.gridx = 0;
        c.gridy = 3;
        form.add(new JLabel("Duracion (min)"), c);
        c.gridx = 1;
        form.add(spDuracion, c);

        c.gridx = 0;
        c.gridy = 4;
        form.add(new JLabel("Genero"), c);
        c.gridx = 1;
        form.add(cbGenero, c);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botones.add(btnLimpiar);
        botones.add(btnCancelar);
        botones.add(btnGuardar);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(form, BorderLayout.CENTER);
        getContentPane().add(botones, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);

        btnLimpiar.addActionListener(e -> {
            txtTitulo.setText("");
            txtDirector.setText("");
            spAnio.setValue(java.time.Year.now().getValue());
            spDuracion.setValue(90);
            cbGenero.setSelectedIndex(0);
            txtTitulo.requestFocus();
        });

        btnCancelar.addActionListener(e -> {
            confirmado = false;
            setVisible(false);
        });

        btnGuardar.addActionListener(e -> {
            if (!validar()) {
                return;
            }
            resultado = new Pelicula(
                    null,
                    txtTitulo.getText().trim(),
                    txtDirector.getText().trim(),
                    (Integer) spAnio.getValue(),
                    (Integer) spDuracion.getValue(),
                    (String) cbGenero.getSelectedItem()
            );
            confirmado = true;
            setVisible(false);
        });
    }

    private boolean validar() {
        if (txtTitulo.getText().trim().isEmpty()
                || txtDirector.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.",
                    "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        int anio = (Integer) spAnio.getValue();
        int dur = (Integer) spDuracion.getValue();
        int currentYear = java.time.Year.now().getValue();
        if (anio < 1888 || anio > currentYear) {
            JOptionPane.showMessageDialog(this, "Anio fuera de rango.",
                    "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (dur <= 0) {
            JOptionPane.showMessageDialog(this, "Duracion debe ser > 0.",
                    "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    public boolean isConfirmado() {
        return confirmado;
    }

    public Pelicula getResultado() {
        return resultado;
    }
}
