package cl.magentacine.ui;

import cl.magentacine.dao.DatabaseConnection;
import cl.magentacine.dao.PeliculaDAO;
import cl.magentacine.model.Pelicula;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class MainFrame extends JFrame {

    private final PeliculaDAO dao = new PeliculaDAO();

    private final JButton btnListar = new JButton("Listar");
    private final JButton btnAgregar = new JButton("Agregar");

    private final JTable tabla = new JTable();
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Titulo", "Director", "Anio", "Duracion", "Genero"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    private final JLabel lblStatus = new JLabel("Estado: ");

    public MainFrame() {
        super("Magenta Cine - Cartelera (GUI)");

        // Barra de menu
        JMenuBar mb = new JMenuBar();
        JMenu mArchivo = new JMenu("Archivo");
        JMenuItem miSalir = new JMenuItem("Salir");
        miSalir.addActionListener(e -> System.exit(0));
        mArchivo.add(miSalir);
        JMenu mPeliculas = new JMenu("Peliculas");
        JMenuItem miAgregar = new JMenuItem("Agregar");
        miAgregar.addActionListener(e -> onAgregar());
        JMenuItem miListar = new JMenuItem("Listar");
        miListar.addActionListener(e -> cargarTabla());
        mPeliculas.add(miAgregar);
        mPeliculas.add(miListar);
        mb.add(mArchivo);
        mb.add(mPeliculas);
        setJMenuBar(mb);

        // Toolbar 
        JToolBar tb = new JToolBar();
        tb.setFloatable(false);
        tb.add(btnAgregar);
        tb.add(btnListar);

        // Centro: tabla
        tabla.setModel(modeloTabla);
        JScrollPane sp = new JScrollPane(tabla);

        // Status bar
        JPanel status = new JPanel(new BorderLayout());
        status.add(lblStatus, BorderLayout.WEST);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(tb, BorderLayout.NORTH);
        getContentPane().add(sp, BorderLayout.CENTER);
        getContentPane().add(status, BorderLayout.SOUTH);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 540);
        setLocationRelativeTo(null);

        // Acciones
        btnAgregar.addActionListener(e -> onAgregar());
        btnListar.addActionListener(e -> cargarTabla());

        // Al iniciar verifica  conexión y listar
        checkConexion();
        cargarTabla();
    }

    private void checkConexion() {
        try (Connection cn = DatabaseConnection.getConnection(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT DATABASE(), @@port")) {
            if (rs.next()) {
                lblStatus.setText("Estado: Conectado a DB=" + rs.getString(1) + " puerto=" + rs.getInt(2));
                JOptionPane.showMessageDialog(this, "Conexion a MySQL exitosa.", "Conexion",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            lblStatus.setText("Estado: ERROR de conexion (" + ex.getMessage() + ")");
            JOptionPane.showMessageDialog(this, "Error de conexion: " + ex.getMessage(), "Conexion",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla() {
        try {
            List<Pelicula> data = dao.findAll();
            render(data);
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void onAgregar() {
        PeliculaFormDialog dlg = new PeliculaFormDialog(this);
        dlg.setVisible(true);
        if (dlg.isConfirmado()) {
            try {
                Pelicula p = dlg.getResultado();
                int id = dao.insert(p);
                if (id > 0) {
                    JOptionPane.showMessageDialog(this, "Registrado con id " + id);
                    cargarTabla(); // refrescar lista
                }
            } catch (Exception ex) {
                showError(ex);
            }
        }
    }

    private void render(List<Pelicula> data) {
        modeloTabla.setRowCount(0);
        for (Pelicula p : data) {
            modeloTabla.addRow(new Object[]{
                p.getId(), p.getTitulo(), p.getDirector(), p.getAnio(), p.getDuracion(), p.getGenero()
            });
        }
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Punto de entrada
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
