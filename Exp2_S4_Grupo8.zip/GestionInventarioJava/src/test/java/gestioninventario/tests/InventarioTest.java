package cl.gestioninventario.tests;

import cl.gestioninventario.model.Producto;
import cl.gestioninventario.service.Inventario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class InventarioTest {

    private Inventario inv;

    @BeforeEach
    void setUp() {
        inv = new Inventario();
    }

    @Test
    void agregar_ok_y_total() {
        inv.agregarProducto(new Producto("P100", "Teclado", 29990));
        assertEquals(1, inv.listarTodos().size());
    }

    @Test
    void agregar_null_lanza() {
        assertThrows(IllegalArgumentException.class, () -> inv.agregarProducto(null));
    }

    @Test
    void agregar_duplicado_lanza() {
        inv.agregarProducto(new Producto("X1", "A", 1));
        assertThrows(IllegalArgumentException.class,
                () -> inv.agregarProducto(new Producto("X1", "B", 2)));
    }

    @Test
    void buscar_por_codigo_ok() {
        Producto p = new Producto("P101", "Mouse", 9990);
        inv.agregarProducto(p);
        assertSame(p, inv.buscarProductoPorCodigo("P101"));
    }

    @Test
    void buscar_codigo_invalido_lanza() {
        assertThrows(IllegalArgumentException.class, () -> inv.buscarProductoPorCodigo("  "));
    }

    @Test
    void buscar_inexistente_lanza() {
        assertThrows(java.util.NoSuchElementException.class,
                () -> inv.buscarProductoPorCodigo("NOPE"));
    }

    @Test
    void actualizar_producto_ok() {
        inv.agregarProducto(new Producto("A1", "Old", 1));
        inv.actualizarProducto("A1", "New", 2.5);
        Producto p = inv.buscarProductoPorCodigo("A1");
        assertAll(
            () -> assertEquals("New", p.getNombre()),
            () -> assertEquals(2.5, p.getPrecio(), 0.0001)
        );
    }

    @Test
    void actualizar_con_nulos_mantiene_valores() {
        inv.agregarProducto(new Producto("A2", "Nombre", 10));
        inv.actualizarProducto("A2", null, null);
        Producto p = inv.buscarProductoPorCodigo("A2");
        assertAll(
            () -> assertEquals("Nombre", p.getNombre()),
            () -> assertEquals(10, p.getPrecio(), 0.0001)
        );
    }

    @Test
    void eliminar_ok_y_false_si_no_existe() {
        inv.agregarProducto(new Producto("B1", "X", 1));
        assertTrue(inv.eliminarProducto("B1"));
        assertFalse(inv.eliminarProducto("B1"));
    }

    @Test
    void listar_ordenado_por_nombre() {
        inv.agregarProducto(new Producto("1", "teclado", 1));
        inv.agregarProducto(new Producto("2", "Alfa", 1));
        assertEquals("Alfa", inv.listarOrdenadosPorNombre().get(0).getNombre());
    }

    @Test
    void csv_exportar_y_cargar(@TempDir Path tmpDir) throws Exception {
        inv.agregarProducto(new Producto("C1", "Uno", 1.5));
        inv.agregarProducto(new Producto("C2", "Dos", 2.5));

        File file = tmpDir.resolve("inv_test.csv").toFile();
        String ruta = file.getAbsolutePath();

        inv.generarInformeInventario(ruta);

        Inventario inv2 = new Inventario();
        int n = inv2.cargarDesdeCSV(ruta);
        assertAll(
            () -> assertEquals(2, n),
            () -> assertEquals(2, inv2.listarTodos().size())
        );
    }
}