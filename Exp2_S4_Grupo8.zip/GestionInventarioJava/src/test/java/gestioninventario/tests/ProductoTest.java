package cl.gestioninventario.tests;

import cl.gestioninventario.model.Producto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductoTest {

    @Test
    void constructor_ok() {
        Producto p = new Producto("P1", "Teclado", 29990);
        assertEquals("P1", p.getCodigo());
        assertEquals("Teclado", p.getNombre());
        assertEquals(29990, p.getPrecio(), 0.0001);
    }

    @Test
    void constructor_codigo_invalido() {
        assertThrows(IllegalArgumentException.class, () -> new Producto("  ", "X", 1));
    }

    @Test
    void constructor_nombre_invalido() {
        assertThrows(IllegalArgumentException.class, () -> new Producto("A1", " ", 1));
    }

    @Test
    void constructor_precio_negativo() {
        assertThrows(IllegalArgumentException.class, () -> new Producto("A1", "X", -1));
    }

    @Test
    void setters_y_actualizarPrecio() {
        Producto p = new Producto("Z9", "X", 10);
        p.setNombre("Mouse");
        p.setPrecio(12.5);
        p.actualizarPrecio(15.0);
        assertAll(
            () -> assertEquals("Mouse", p.getNombre()),
            () -> assertEquals(15.0, p.getPrecio(), 0.0001)
        );
    }

    @Test
    void setNombre_invalido() {
        Producto p = new Producto("Z9", "X", 10);
        assertThrows(IllegalArgumentException.class, () -> p.setNombre("  "));
    }

    @Test
    void setPrecio_negativo() {
        Producto p = new Producto("Z9", "X", 10);
        assertThrows(IllegalArgumentException.class, () -> p.setPrecio(-5));
    }

    @Test
    void equals_hashCode_por_codigo() {
        Producto a = new Producto("K1", "A", 1);
        Producto b = new Producto("K1", "B", 2);
        Producto c = new Producto("K2", "A", 1);
        assertAll(
            () -> assertTrue(a.equals(b)),
            () -> assertEquals(a.hashCode(), b.hashCode()),
            () -> assertFalse(a.equals(c))
        );
    }

    @Test
    void descripcionDetallada_contiene_datos() {
        Producto p = new Producto("ABC", "Teclado", 29990.0);
        String s = p.descripcionDetallada();
        assertAll(
            () -> assertTrue(s.contains("ABC")),
            () -> assertTrue(s.toLowerCase().contains("teclado")),
            () -> assertTrue(s.contains("29990.00"))
        );
    }
}