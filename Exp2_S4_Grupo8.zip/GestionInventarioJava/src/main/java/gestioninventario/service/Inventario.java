package cl.gestioninventario.service;
import cl.gestioninventario.model.Producto;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Inventario {
    private HashMap<String, Producto> productos;

    public Inventario() {
        this.productos = new HashMap<>();
    }

    public void agregarProducto(Producto producto) {
        if (producto == null) throw new IllegalArgumentException("Producto nulo.");
        String codigo = producto.getCodigo();
        if (productos.containsKey(codigo))
            throw new IllegalArgumentException("Ya existe un producto con codigo " + codigo);
        productos.put(codigo, producto);
    }

    // TODO: metodo para buscar productos por codigo
    public Producto buscarProductoPorCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty())
            throw new IllegalArgumentException("Codigo invalido.");
        Producto p = productos.get(codigo.trim());
        if (p == null) throw new NoSuchElementException("No existe producto con codigo " + codigo);
        return p;
    }

    public void actualizarProducto(String codigo, String nuevoNombre, Double nuevoPrecio) {
        Producto p = buscarProductoPorCodigo(codigo);
        if (nuevoNombre != null && !nuevoNombre.trim().isEmpty()) p.setNombre(nuevoNombre);
        if (nuevoPrecio != null) p.actualizarPrecio(nuevoPrecio);
    }

    public boolean eliminarProducto(String codigo) {
        return productos.remove(codigo) != null;
    }

    public List<Producto> listarTodos() {
        return new ArrayList<>(productos.values());
    }

    public List<Producto> listarOrdenadosPorNombre() {
        ArrayList<Producto> lista = new ArrayList<>(productos.values());
        lista.sort(Comparator.comparing(Producto::getNombre, String.CASE_INSENSITIVE_ORDER));
        return lista;
    }

    public List<Producto> buscarPorNombre(String texto) {
        if (texto == null) texto = "";
        String needle = texto.trim().toLowerCase(java.util.Locale.ROOT);
        ArrayList<Producto> out = new ArrayList<>();
        for (Producto p : productos.values()) {
            if (p.getNombre().toLowerCase(java.util.Locale.ROOT).contains(needle)) out.add(p);
        }
        return out;
    }

    // TODO: metodo para generar informes del inventario
    public void generarInformeInventario(String ruta) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write("codigo;nombre;precio");
            bw.newLine();
            for (Producto p : listarOrdenadosPorNombre()) {
                bw.write(String.format(java.util.Locale.US,
                        "%s;%s;%.2f", p.getCodigo(), p.getNombre(), p.getPrecio()));
                bw.newLine();
            }
        }
    }

    // soporte de carga CSV para pruebas de integracion y persistencia
    public int cargarDesdeCSV(String ruta) throws IOException {
        int cargados = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            boolean primera = true;
            while ((linea = br.readLine()) != null) {
                String row = linea.trim();
                if (row.isEmpty()) continue;
                if (primera && row.toLowerCase(java.util.Locale.ROOT).startsWith("codigo;")) {
                    primera = false;
                    continue;
                }
                primera = false;

                String[] parts = row.split(";", -1);
                if (parts.length < 3) continue;

                String codigo = parts[0].trim();
                String nombre = parts[1].trim();
                String precioTxt = parts[2].trim().replace(',', '.');

                try {
                    double precio = Double.parseDouble(precioTxt);
                    Producto p = new Producto(codigo, nombre, precio);
                    productos.put(codigo, p);
                    cargados++;
                } catch (IllegalArgumentException e) {
                    // fila invalida: se omite
                }
            }
        }
        return cargados;
    }
}