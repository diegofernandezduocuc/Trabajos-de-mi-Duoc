package cl.gestioninventario.ui;
import cl.gestioninventario.model.Producto;
import cl.gestioninventario.service.Inventario;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class MenuPrincipal {
    private final Inventario inventario;
    private final Scanner sc = new Scanner(System.in);

    public MenuPrincipal(Inventario inventario) {
        this.inventario = inventario;
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Elige una  opcion: ");
            try {
                switch (opcion) {
                    case 1: opcionAgregar(); break;
                    case 2: opcionActualizar(); break;
                    case 3: opcionEliminar(); break;
                    case 4: opcionBuscarPorCodigo(); break;
                    case 5: opcionBuscarPorNombre(); break;
                    case 6: opcionListar(); break;
                    case 7: opcionGuardarCSV(); break;
                    case 8: System.out.println("Saliendo..."); break;
                    default: System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | NoSuchElementException e) {
                System.out.println("Ups: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error inesperado: " + e);
            }
        } while (opcion != 8);
    }

    private void mostrarMenu() {
        System.out.println("\n==== Gestion de Inventario ====");
        System.out.println("1) Agregar producto");
        System.out.println("2) Actualizar producto");
        System.out.println("3) Eliminar producto");
        System.out.println("4) Buscar por codigo");
        System.out.println("5) Buscar por nombre");
        System.out.println("6) Listar inventario");
        System.out.println("7) Guardar CSV");
        System.out.println("8) Salir");
    }

    private void opcionAgregar() {
        System.out.println("\n-- Agregar --");
        String codigo = leerTexto("Codigo: ");
        String nombre = leerTexto("Nombre: ");
        double precio = leerDouble("Precio: ");
        Producto p = new Producto(codigo, nombre, precio);
        inventario.agregarProducto(p);
        System.out.println("Guardado: " + p);
    }

    private void opcionActualizar() {
        System.out.println("\n-- Actualizar --");
        String codigo = leerTexto("Codigo existente: ");
        String nombre = leerOpcional("Nuevo nombre (Enter para omitir): ");
        Double precio = leerDoubleOpcional("Nuevo precio (Enter para omitir): ");
        inventario.actualizarProducto(codigo, nombre.isEmpty()? null : nombre, precio);
        System.out.println("Actualizado.");
    }

    private void opcionEliminar() {
        System.out.println("\n-- Eliminar --");
        String codigo = leerTexto("Codigo: ");
        boolean ok = inventario.eliminarProducto(codigo);
        System.out.println(ok ? "Eliminado." : "No encontrado.");
    }

    private void opcionBuscarPorCodigo() {
        System.out.println("\n-- Buscar por codigo --");
        String codigo = leerTexto("Codigo: ");
        Producto p = inventario.buscarProductoPorCodigo(codigo);
        System.out.println(p);
    }

    private void opcionBuscarPorNombre() {
        System.out.println("\n-- Buscar por nombre --");
        String texto = leerTexto("Texto: ");
        List<Producto> res = inventario.buscarPorNombre(texto);
        if (res.isEmpty()) System.out.println("(sin resultados)");
        else res.forEach(x -> System.out.println(" - " + x));
    }

    private void opcionListar() {
        System.out.println("\n-- Listado --");
        List<Producto> todos = inventario.listarOrdenadosPorNombre();
        if (todos.isEmpty()) System.out.println("(inventario vacio)");
        else todos.forEach(x -> System.out.println(" - " + x));
        System.out.println("Total: " + todos.size());
    }

    private void opcionGuardarCSV() {
        System.out.println("\n-- Guardar CSV --");
        String ruta = leerTexto("Ruta (ej: inventario.csv): ");
        try {
            inventario.generarInformeInventario(ruta);
            System.out.println("CSV generado en: " + ruta);
        } catch (IOException e) {
            System.out.println("No se pudo guardar: " + e.getMessage());
        }
    }

    private String leerTexto(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private String leerOpcional(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private int leerEntero(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            try { return Integer.parseInt(s.trim()); }
            catch (NumberFormatException e) { System.out.println("Debe ser un numero entero."); }
        }
    }

    private double leerDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            try { return Double.parseDouble(s.trim().replace(',', '.')); }
            catch (NumberFormatException e) { System.out.println("Debe ser un numero (usa punto)."); }
        }
    }

    private Double leerDoubleOpcional(String prompt) {
        System.out.print(prompt);
        String s = sc.nextLine().trim().replace(',', '.');
        if (s.isEmpty()) return null;
        return Double.parseDouble(s);
    }
}