package cl.gestioninventario.app;

import cl.gestioninventario.service.Inventario;
import cl.gestioninventario.ui.MenuPrincipal;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    private static final String DEFAULT_CSV = "inventario.csv";

    public static void main(String[] args) {
        Inventario inv = new Inventario();

        String rutaCsv = (args.length > 0 && args[0] != null && !args[0].isBlank())
                ? args[0]
                : DEFAULT_CSV;

        try {
            Path p = Paths.get(rutaCsv);
            if (Files.exists(p)) {
                int n = inv.cargarDesdeCSV(rutaCsv);
                System.out.println("Inventario cargado: " + n + " productos.");
            } else {
                System.out.println("No se encontro " + rutaCsv + ". Inventario vacio.");
            }
        } catch (Exception e) {
            System.out.println("No se pudo cargar CSV: " + e.getMessage());
        }

        new MenuPrincipal(inv).iniciar();

        try {
            inv.generarInformeInventario(rutaCsv);
            System.out.println("Inventario guardado en " + rutaCsv);
        } catch (Exception e) {
            System.out.println("No se pudo guardar: " + e.getMessage());
        }
    }
}