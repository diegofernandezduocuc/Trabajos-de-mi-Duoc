package cl.gestioninventario.model;
import java.util.Objects;
public class Producto {
    private String codigo;
    private String nombre;
    private double precio;

    public Producto(String codigo, String nombre, double precio) {
        if (codigo == null || codigo.trim().isEmpty())
            throw new IllegalArgumentException("El codigo no puede ser nulo o vacio.");
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("El nombre no puede ser nulo o vacio.");
        if (precio < 0)
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        this.codigo = codigo.trim();
        this.nombre = nombre.trim();
        this.precio = precio;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty())
            throw new IllegalArgumentException("Codigo invalido.");
        this.codigo = codigo.trim();
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("Nombre invalido.");
        this.nombre = nombre.trim();
    }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) {
        if (precio < 0)
            throw new IllegalArgumentException("Precio negativo.");
        this.precio = precio;
    }

    // TODO: metodo para actualizar  precio del producto
    public void actualizarPrecio(double nuevoPrecio) {
        setPrecio(nuevoPrecio);
    }

    //  TODO: metodo para descripcion detallada del producto
    public String descripcionDetallada() {
        return String.format(java.util.Locale.US,
                "Producto[codigo=%s, nombre=%s, precio=%.2f]",
                codigo, nombre, precio);
    }

    @Override
    public String toString() { return descripcionDetallada(); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Producto)) return false;
        Producto that = (Producto) o;
        return Objects.equals(codigo, that.codigo);
    }

    @Override
    public int hashCode() { return Objects.hash(codigo); }
}